import React, { useState, useEffect } from 'react';
import { Github, Linkedin, Mail, ChevronDown, GraduationCap, User, Heart, Coffee, Sparkles, Award, Star } from 'lucide-react';

function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [isScrolled, setIsScrolled] = useState(false);

  // Handle scroll events for navbar transparency
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Smooth scroll to section
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setActiveSection(sectionId);
  };

  // Update active section based on scroll position
  useEffect(() => {
    const handleSectionVisibility = () => {
      const sections = ['home', 'about', 'education', 'achievements', 'contact'];
      const current = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 150 && rect.bottom >= 150;
        }
        return false;
      });
      if (current) {
        setActiveSection(current);
      }
    };

    window.addEventListener('scroll', handleSectionVisibility);
    return () => window.removeEventListener('scroll', handleSectionVisibility);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white">
      {/* Navigation Bar */}
      <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-black/50 backdrop-blur-md' : ''}`}>
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-pink-400 to-indigo-400">
              VN
            </span>
            <div className="hidden md:flex space-x-8">
              {['home', 'about', 'education', 'achievements', 'contact'].map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className={`capitalize transition-colors ${
                    activeSection === section 
                    ? 'text-pink-400' 
                    : 'text-gray-300 hover:text-pink-400'
                  }`}
                >
                  {section}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="min-h-screen flex flex-col items-center justify-center relative px-4" id="home">
        <div className="text-center">
          <div className="mb-6 animate-bounce">
            <Sparkles className="w-12 h-12 text-yellow-400 mx-auto" />
          </div>
          <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-400 animate-pulse">
            Vishakha Nayak
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-4">
            B.Tech Computer Science Student at Swami Keshwanad Institute of Engineering
          </p>
          <p className="flex items-center justify-center gap-2 text-pink-400 mb-8">
            <Coffee className="w-5 h-5" />
            Aspiring Software Developer & Problem Solver
          </p>
          <div className="flex gap-6 justify-center mb-12">
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" 
               className="transform hover:scale-110 transition-transform hover:text-pink-400">
              <Github className="w-7 h-7" />
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" 
               className="transform hover:scale-110 transition-transform hover:text-pink-400">
              <Linkedin className="w-7 h-7" />
            </a>
            <a href="mailto:nayakvishakha996@gmail.com" 
               className="transform hover:scale-110 transition-transform hover:text-pink-400">
              <Mail className="w-7 h-7" />
            </a>
          </div>
        </div>
        <button 
          onClick={() => scrollToSection('about')}
          className="absolute bottom-8 animate-bounce hover:text-pink-400 transition-colors"
        >
          <ChevronDown className="w-8 h-8" />
        </button>
      </header>

      {/* About Section */}
      <section className="py-20 px-4 min-h-screen flex items-center" id="about">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-2 mb-8">
            <User className="w-6 h-6 text-pink-400" />
            <h2 className="text-3xl font-bold">About Me</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-12">
            <div className="relative group">
              <img
                src="https://img.freepik.com/premium-vector/young-woman-is-working-desk-with-laptop-woman-workplace-with-cup-coffee_530689-1946.jpg"
                alt="Girl with Coffee Illustration"
                className="rounded-lg shadow-xl transform group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-pink-900/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-end">
                <p className="text-white p-4">📍 Jaipur, Rajasthan</p>
              </div>
            </div>
            <div className="flex flex-col justify-center space-y-4">
              <p className="text-gray-300">
                Aspiring computer science student seeking challenging opportunities to apply my technical skills and contribute to innovative projects. Passionate about software development, algorithms, and problem-solving.
              </p>
              <div className="bg-white/10 p-4 rounded-lg backdrop-blur-sm transform hover:scale-105 transition-all duration-300">
                <h3 className="font-semibold mb-2 text-pink-400">Technical Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {[
                    'HTML/CSS', 'JavaScript', 'Flutter', 'ReactJS', 'Java',
                    'UI/UX Design', 'Data Structures', 'MySQL'
                  ].map((skill) => (
                    <span key={skill} className="px-3 py-1 bg-white/10 rounded-full text-sm hover:bg-white/20 transition-colors">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div className="bg-white/10 p-4 rounded-lg backdrop-blur-sm transform hover:scale-105 transition-all duration-300">
                <h3 className="font-semibold mb-2 text-pink-400">Soft Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {[
                    'Management', 'Negotiation', 'Critical Thinking', 'Leadership',
                    'Public Speaking'
                  ].map((skill) => (
                    <span key={skill} className="px-3 py-1 bg-white/10 rounded-full text-sm hover:bg-white/20 transition-colors">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section className="py-20 px-4 bg-black/20 backdrop-blur-sm min-h-screen flex items-center" id="education">
        <div className="max-w-4xl mx-auto w-full">
          <div className="flex items-center gap-2 mb-8">
            <GraduationCap className="w-6 h-6 text-pink-400" />
            <h2 className="text-3xl font-bold">Education</h2>
          </div>
          <div className="space-y-8">
            <div className="bg-white/5 p-6 rounded-lg backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <h3 className="text-xl font-bold mb-1">Bachelor of Technology in Computer Science</h3>
              <div className="text-pink-400 mb-2">Swami Keshwanad Institute of Engineering, Jaipur • 2022 - 2026</div>
              <p className="text-gray-300">Pursuing B.Tech with a focus on computer science and software development.</p>
            </div>
            <div className="bg-white/5 p-6 rounded-lg backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <h3 className="text-xl font-bold mb-1">Higher Secondary Education</h3>
              <div className="text-pink-400 mb-2">MDS Sr. Sec. School, Udaipur</div>
            </div>
            <div className="bg-white/5 p-6 rounded-lg backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <h3 className="text-xl font-bold mb-1">Secondary Education</h3>
              <div className="text-pink-400 mb-2">St. Paul's Sr. Sec. School, Udaipur</div>
            </div>
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="py-20 px-4 min-h-screen flex items-center" id="achievements">
        <div className="max-w-4xl mx-auto w-full">
          <div className="flex items-center gap-2 mb-8">
            <Award className="w-6 h-6 text-pink-400" />
            <h2 className="text-3xl font-bold">Achievements & Activities</h2>
          </div>
          <div className="grid gap-6">
            <div className="bg-white/5 p-6 rounded-lg backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <div className="flex items-start gap-4">
                <Star className="w-6 h-6 text-yellow-400 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-xl font-bold mb-2">Technical Fest Winner</h3>
                  <p className="text-gray-300">Won cash prize worth ₹2100/- at GIT Jaipur Technical Fest Codefiesta for the Traffic Management System project (Hardware category)</p>
                </div>
              </div>
            </div>
            <div className="bg-white/5 p-6 rounded-lg backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <div className="flex items-start gap-4">
                <Star className="w-6 h-6 text-yellow-400 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-xl font-bold mb-2">IIT Jodhpur Prometeo</h3>
                  <p className="text-gray-300">Developed a project on increasing the use of wishlist options in online shopping platforms</p>
                </div>
              </div>
            </div>
            <div className="bg-white/5 p-6 rounded-lg backdrop-blur-sm border border-white/10 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <div className="flex items-start gap-4">
                <Star className="w-6 h-6 text-yellow-400 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-xl font-bold mb-2">Volunteer Experience</h3>
                  <p className="text-gray-300">Active participation in major central level events at Swami Keshwanad Institute of Technology</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 px-4 bg-black/20 backdrop-blur-sm min-h-screen flex items-center" id="contact">
        <div className="max-w-4xl mx-auto text-center w-full">
          <h2 className="text-3xl font-bold mb-8">Get In Touch</h2>
          <div className="flex flex-col md:flex-row items-center justify-center gap-8">
            <a href="tel:7976733846" 
               className="flex items-center gap-2 text-pink-400 hover:text-pink-300 transform hover:scale-105 transition-all">
              <span className="text-lg">📱 +91 7976733846</span>
            </a>
            <a href="mailto:nayakvishakha996@gmail.com" 
               className="flex items-center gap-2 text-pink-400 hover:text-pink-300 transform hover:scale-105 transition-all">
              <Mail className="w-5 h-5" />
              <span className="text-lg">nayakvishakha996@gmail.com</span>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-4">
          <div className="flex justify-center gap-2 items-center text-pink-400">
            <Heart className="w-5 h-5" />
            <span>Thank you for visiting!</span>
          </div>
          <p className="text-gray-400">© 2024 Vishakha Nayak • Built with React & Tailwind CSS</p>
        </div>
      </footer>
    </div>
  );
}

export default App;